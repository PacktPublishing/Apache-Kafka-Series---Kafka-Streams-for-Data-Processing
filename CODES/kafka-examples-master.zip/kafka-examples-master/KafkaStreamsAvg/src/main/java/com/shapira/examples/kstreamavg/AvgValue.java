package com.shapira.examples.kstreamavg;


public class AvgValue {
    Integer count;
    Integer sum;

    public AvgValue(Integer count, Integer sum) {
        this.count = count;
        this.sum = sum;
    }

}
