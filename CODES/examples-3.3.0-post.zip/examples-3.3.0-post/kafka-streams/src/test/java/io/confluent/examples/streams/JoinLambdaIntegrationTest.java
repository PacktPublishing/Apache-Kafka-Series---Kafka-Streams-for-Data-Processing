package io.confluent.examples.streams;

/**
 * JoinLambdaIntegrationTest was renamed to StreamToTableJoinIntegrationTest.
 */
public class JoinLambdaIntegrationTest {
}
