package io.confluent.examples.streams

/**
  * JoinScalaIntegrationTest was renamed to StreamToTableJoinScalaIntegrationTest.
  */
class JoinScalaIntegrationTest {
}
